// Enumeración para tipo de componente
enum ComponentType {
    TRANSFORM,
    // otros tipos posibles...
};

// Clase base
class Component {
protected:
    ComponentType type;

public:
    // Constructor con tipo
    Component(ComponentType t) {
        type = t;
    }

    // Getter del tipo
    ComponentType GetType() {
        return type;
    }
};

// Tipo de vector (similar a sf::Vector2f)
class Vector2F {
public:
    float x;
    float y;

    // Constructor por defecto
    Vector2F() {
        x = 0.0;
        y = 0.0;
    }

    // Constructor con parámetros
    Vector2F(float xVal, float yVal) {
        x = xVal;
        y = yVal;
    }
};

// Clase Transform heredando de Component
class Transform : public Component {
private:
    Vector2F position;
    Vector2F rotation;
    Vector2F scale;

public:
    // Constructor por defecto
    Transform() : Component(TRANSFORM) {
        position = Vector2F(0.0, 0.0);
        rotation = Vector2F(0.0, 0.0);
        scale = Vector2F(1.0, 1.0);  // usualmente se inicializa el scale en 1
    }

    // Getters
    Vector2F GetPosition() {
        return position;
    }

    Vector2F GetRotation() {
        return rotation;
    }

    Vector2F GetScale() {
        return scale;
    }

    // Setters
    void SetPosition(Vector2F newPos) {
        position = newPos;
    }

    void SetRotation(Vector2F newRot) {
        rotation = newRot;
    }

    void SetScale(Vector2F newScale) {
        scale = newScale;
    }
};